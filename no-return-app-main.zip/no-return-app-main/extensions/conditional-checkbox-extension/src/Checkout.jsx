import {
  useApi,
  reactExtension,
  useCartLines,
  Checkbox,
  Spinner,
  useBuyerJourneyIntercept,
  useExtensionCapability,
  useApplyAttributeChange,
} from '@shopify/ui-extensions-react/checkout';
import { useEffect, useState } from 'react';

export default reactExtension(
  'purchase.checkout.block.render',
  () => <Extension />,
);

function Extension() {
  const { query, storage } = useApi();
  const cartLines = useCartLines();
  const productTitles = cartLines.map(line => line.merchandise.title);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isChecked, setIsChecked] = useState(false);
  const [validationError, setValidationError] = useState("");
  const canBlockProgress = useExtensionCapability("block_progress");
  const applyAttributeChange = useApplyAttributeChange()

  // checkbox click handler 
  const handleCheckboxChange = () => {
    storage
      .write('isChecked', !isChecked)
      .catch((error) => console.error('Error While saving no return check marked:', error));
    setIsChecked(!isChecked);
    applyAttributeChange({
      key: 'Tax Included',
      type: 'updateAttribute',
      value: 'Agreed to Include Tax',
    });
    setValidationError("");
  };

  // fetch data that was stored in the check box
  const fetchData = async () => {
    try {
      const storeNoReturnChecked = await storage.read('isChecked');
      //@ts-ignore
      setIsChecked(storeNoReturnChecked)
    } catch (error) {
      console.error('Error while reading timer data:', error);
    }
  };

  // use intercept hook to stop users progress i.e disable the continue button
  useBuyerJourneyIntercept(({ canBlockProgress }) => {
    if (canBlockProgress && allTags.includes('no-return') && !isChecked) {
      return {
        behavior: "block",
        reason: "Please indicate that you accept the Terms and Conditions",
        perform: (result) => {
          if (result.behavior === "block") {
            setValidationError("Please indicate that you accept the Terms and Conditions");
          }
        },
      };
    }

    return {
      behavior: "allow",
      perform: () => {
        clearValidationErrors();
      },
    };
  });

  function clearValidationErrors() {
    setValidationError("");
  }


  // fetching all the products using their titles
  async function fetchProducts(productTitle) {
    setLoading(true);
    try {
      const { data } = await query(
        // Graph QL Query to retrieve product of cart from the admin 
        `query {  
          products(first: 100, query: "${productTitle}") {
            nodes {
              id
              title
              tags
            }
          }
        }`,
        {
          variables: { first: 10 },
        }
      );
      // @ts-ignore
      setProducts((prevProducts) => {
        if (prevProducts) {
          // storing all the product in a single array for better use
          const mergedProducts = [...prevProducts, ...data.products.nodes];
          return mergedProducts;
        } else {
          return data.products.nodes;
        }
      });

    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    // calling the fetch product function when window is loaded 
    productTitles.forEach((fetchProduct) => {
      fetchProducts(fetchProduct);
    })
    fetchData();
  }, []);

  useEffect(() => {
    // calling the fetch data function when ever there is change in the storage values
    fetchData();
  }, [storage]);

  // separating all the tags from all the products to into a single array 
  // flatmap very similar to map but it spreads any array it finds in the key 
  const allTags = products.flatMap(product => product.tags)

  return (
    <>
      {loading ? (
        <Spinner />
      ) : allTags.includes('tax') && (
        <Checkbox value={isChecked}
          onChange={handleCheckboxChange}
          onInput={clearValidationErrors}
          required={canBlockProgress}
          error={validationError}
        >
          Agreed to pay Tax
        </Checkbox>
      )
      }
    </>
  );
}
